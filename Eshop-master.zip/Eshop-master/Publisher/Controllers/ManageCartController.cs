﻿using Publisher.Models;
using Publisher.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Publisher.Controllers
{
    public class ManageCartController : ApiController
    {

        ManageBasketRepository repository;
        public ManageCartController()
        {
            repository = new ManageBasketRepository();
        }


        // GET: api/ManageCart
        public IEnumerable<Basket> Get()
        {
           
                Basket basket = new Basket()
                {
                    User = "10",
                    Products = new List<ProductQty>
                {
                    new ProductQty(){
                    ProductId = "1",
                    Quantity = 24,
                    Price = 12,
                    Total = 100
                }
                }
                };

                string userId = basket.User;
           
             yield return repository.AddBasketForUser(userId, basket.Products);
            
            // return new string[] { "value1", "value2" };
        }

        // GET: api/ManageCart/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/ManageCart
        public HttpResponseMessage Post([FromBody]Basket Basketa)
        {
            try { 
            Basket basket = new Basket()
            {
                User = "10",
                Products = new List<ProductQty>
                {
                    new ProductQty(){
                    ProductId = "1",
                    Quantity = 24,
                    Price = 12,
                    Total = 100
                }
                }
            };
            string userId = Basketa.User;
            repository.AddBasketForUser(userId, Basketa.Products);
           
            }
            catch (Exception e)
            {
                return null;
                //error will bubble up
            }
            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // PUT: api/ManageCart/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/ManageCart/5
        public void Delete(int id)
        {
        }
    }
}
