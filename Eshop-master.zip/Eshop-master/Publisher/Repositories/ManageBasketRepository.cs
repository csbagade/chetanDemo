﻿using Publisher.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Publisher.Repositories
{
    public class ManageBasketRepository
    {
        private static List<Basket> baskets = null;
        public ManageBasketRepository()
        {
            if (baskets == null)
            {
                baskets = new List<Basket>()
                {
                    new Basket(){
                            User = "10",
                            Products = new List<ProductQty>
                            {
                                        new ProductQty(){
                                        ProductId = "1",
                                        Quantity = 24,
                                        Price = 12,
                                        Total = 100
                                    }
                            }
                    }
                };
            }
        }

        public Basket AddBasketForUser(string userId, List<ProductQty> products)
        {
            CatalogRepository catalogRepository = new CatalogRepository();
            Basket basket = baskets.FirstOrDefault(item => item.User == userId);
            try
            {
                if (basket == null)
                {
                    throw new Exception("Basket not available");
                }

                foreach (var item in products)
                {

                    ProductQty product = basket.Products.FirstOrDefault(p => p.ProductId == item.ProductId);
                    if (product == null)
                    {
                        Models.Catalog catalog = catalogRepository.GetCatalogs(item.ProductId);
                        ProductQty p = new ProductQty();
                        p.ProductId = catalog.Id;
                        p.Quantity = item.Quantity;
                        basket.Products.Add(p);
                    }
                    else
                    {
                        basket.Products.Remove(product);
                        product.ProductId = item.ProductId;
                        product.Quantity = item.Quantity;
                        basket.Products.Add(product);
                    }
                }
            }
            catch (Exception e)
            { }
            return basket;
        }
    }
}
