﻿$(function () {
    $(document).on('click', 'a.qty-minus', function (e) {
        e.preventDefault();
        var $this = $(this);
        var $input = $this.closest('div').find('input');
        var value = parseInt($input.val());

        if (value > 1) {
            value = value - 1;
        } else {
            value = 0;
        }

        $input.val(value);
        Calculate();
    });


    $(document).on('click', 'a.qty-plus', function (e) {
        e.preventDefault();
        var $this = $(this);
        var $input = $this.closest('div').find('input');
        var value = parseInt($input.val());

        if (value < 100) {
            value = value + 1;
        } else {
            value = 100;
        }

        $input.val(value);
        Calculate();
    });


    $(document).on('click', '.visibility-cart', function () {
        var $btn = $(this);
        var $cart = $('.cart');
        console.log($btn);

        if ($btn.hasClass('is-open')) {
            $btn.removeClass('is-open');
            $btn.text('O')
            $cart.removeClass('is-open');
            $cart.addClass('is-closed');
            $btn.addClass('is-closed');
        } else {
            $btn.addClass('is-open');
            $btn.text('X')
            $cart.addClass('is-open');
            $cart.removeClass('is-closed');
            $btn.removeClass('is-closed');
        }

    });


    $(document).on('blur', 'input', function () {
        var input = $(this);
        var value = parseInt($(this).val());

        if (value < 0 || isNaN(value)) {
            input.val(0);
        } else if
        (value > 100) {
            input.val(100);
        }
        Calculate();
    });

    function Calculate() {
        var totalCart = 0;
        $(".calc").each(function (index) {
            var $this = $(this);
            var price = $this.find(".col-price").text().trim();
            //$(".col - qty")
           
            var $input = $this.closest('div').find('input');
            var qty = parseInt($input.val());

            var total = price * qty;
            $this.find(".col-total")[0].innerText = total;
            totalCart = totalCart + total;
        });

        $(".Total")[0].innerText = totalCart;
        
    }
   

    $(document).on('click', '.btn-update', function () {

        var Basket = [];
        var strng = "{'User':'10','Products':[";

        Basket.User = "10";
        Basket.Products = [];
        $(".calc").each(function (index) {
            var $this = $(this);
            var price = parseInt($this.find(".col-price").text().trim());
            var $input = $this.closest('div').find('input');
            var qty = parseInt($input.val());
            var total = price * qty;
            var ProductId = index + 1;

            var Product = {};
            var prod = "{'ProductId': '" + ProductId.toString() + "','Quantity': " + qty + ", 'Price': " + price + ", 'Total': " + total+"},";
            Product.ProductId = ProductId.toString();
            Product.Quantity = qty;
            Product.Price = price;
            Product.Total = total;
            Basket.Products.push(Product);
            strng = strng + prod;
        });


        strng = strng + "]}";


        var Basketa = { 
                    "User": "10",
                    "Products": [
                        {
                            "ProductId": "1",
                            "Quantity": 24,
                            "Price": 12,
                            "Total": 100
                        }, {
                            "ProductId": "2",
                            "Quantity": 10,
                            "Price": 12,
                            "Total": 100
                        }, {
                            "ProductId": "3",
                            "Quantity": 12,
                            "Price": 12,
                            "Total": 144
                        }]                
        };
         


        ////$.ajax({
        ////    type: "POST",
        ////    url: "http://localhost:58253/api/ManageCart",
        ////    data: JSON.stringify({ value: Basketa }),
        ////    dataType: 'json',
        ////    success: function (response) {
        ////        alert("Successfully posted cart data");
        ////    },
        ////    error: function (xhr, ajaxOptions, thrownError) {
        ////        alert(xhr.status);
        ////        alert(thrownError);
        ////    }
        ////});

        $.post("http://localhost:58253/api/ManageCart", Basketa, function (response,status) { alert("Successfully posted cart data"+ Response.status); }, "json");

        //$.ajax({
        //    type: "POST",
        //    url: "http://localhost:58253/api/ManageCart",
        //    cache: false,
        //    data: JSON.stringify({ Basketa: Basketa }),
        //    contentType: "application/json; charset=utf-8",
        //    traditional: true,
        //    success: () => { result.resolve(true); }
        //   // error: (error) => result.reject(error)
        //});
    });


   




});